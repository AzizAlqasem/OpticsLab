""" Monitor detect and present the results

"""

class Profile:
    
    def __init__(self,):
        pass