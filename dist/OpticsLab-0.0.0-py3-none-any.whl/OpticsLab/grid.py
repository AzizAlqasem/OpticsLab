"""Grid define a space for the setup of the experiment

using Python Turtul/Tkinter here could be usuful
"""

class Grid:
    
    def __init__(self, ):
        pass