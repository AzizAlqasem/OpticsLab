# OpticsLab
Simulate Optical Experiments

### Current Status
  Under Development!
  
#### TimeLine
  2020, Apr: Module created.
