""" Source module
This Module make and prepare the light source
"""



class Laser:
    """ Laser is a class that define the light source as a LASER
    The output should be ready to be used with optical component.
    """
    
    def __init__(self, *args, **kw):
        pass
    



    
    