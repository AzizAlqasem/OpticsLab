""" The components module has all optical components that are used in optics

"""


class Mirror:
    
    def __init__(self,):
        pass


class Lense:
    
    def __init__(self,):
        pass
    

class Mediam:
    
    def __init__(self,):
        pass
    

class BeamSpliter:
    
    def __init__(self,):
        pass


class Waveplate:
    
    def __init__(self,):
        pass